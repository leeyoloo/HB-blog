/* eslint-disable react/no-unknown-property */
import clsx from "clsx";
import { m, useAnimationControls } from "framer-motion";
import { useEffect, useRef, useState } from "react";

interface ImageProps {
  onHover: () => void;
  onHoverEnd: () => void;
}

function StaticImage({ onHover, onHoverEnd }: ImageProps) {
  return (
    <img
      src="/assets/images/coverImage.jpg"
      alt="封面图片"
      className="h-full w-full object-cover rounded-full"
      onMouseEnter={onHover}
      onMouseLeave={onHoverEnd}
      style={{ pointerEvents: "auto" }} // 启用图片的鼠标事件
    />
  );
}

function HeaderImage() {
  const controlsHeaderImage = useAnimationControls();
  const controlsHeaderOutline = useAnimationControls();
  const [loaded] = useState(false);
  const [isButtonVisible, setIsButtonVisible] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [isMenuVisible, setIsMenuVisible] = useState(false);
  const hoverTimerRef = useRef(null);

  useEffect(() => {
    if (loaded) {
      controlsHeaderImage.start({
        opacity: 1,
        transition: { duration: 0.5 },
      });
    }
  }, [loaded, controlsHeaderImage]);

  useEffect(() => {
    if (isHovering) {
      hoverTimerRef.current = setTimeout(() => {
        setIsButtonVisible(true);
      }, 1500);
    } else if (hoverTimerRef.current) {
      clearTimeout(hoverTimerRef.current);
    }

    return () => {
      if (hoverTimerRef.current) {
        clearTimeout(hoverTimerRef.current);
      }
    };
  }, [isHovering]);

  const handleHover = () => {
    setIsHovering(true);
  };

  const handleHoverEnd = () => {
    setIsHovering(false);
  };

  const handleClick = () => {
    setIsMenuVisible(!isMenuVisible); // 切换菜单的显示状态
  };

  return (
    <div className={clsx("relative h-[400px] w-[400px]")}>
      <div className={clsx("absolute top-0 right-0 h-[400px] w-[250px]")}>
        <div className={clsx("absolute right-0 bottom-0 overflow-hidden")}>
          <m.div
            className={clsx("h-[300px] w-[300px]")}
            initial={{ opacity: 1 }}
            animate={controlsHeaderImage}
            style={{ pointerEvents: "auto" }} // 启用图片的鼠标事件
          >
            <div className="animate-spin-slow">
              <StaticImage onHover={handleHover} onHoverEnd={handleHoverEnd} />
            </div>
          </m.div>
        </div>
      </div>

      {isButtonVisible && (
        <m.button
          onClick={handleClick}
          className="absolute bottom-4 right-4 rounded-full bg-blue-500 p-3 text-white shadow-lg transition-colors duration-200 hover:bg-blue-600"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }} // 动画持续时间
          style={{ zIndex: 100, pointerEvents: "auto" }} // 确保按钮在最上层且可以接收点击事件
        >
          预留彩蛋位
        </m.button>
      )}

      {/* {isMenuVisible && (
        <m.div
          className="absolute bottom-4 left-[calc(100%+10px)] w-60 rounded-lg bg-white p-4 shadow-lg"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 20 }}
          transition={{ duration: 0.3 }}
        >
          <h3 className="text-lg font-bold">这里没有彩蛋</h3>
          <ul>
            <li className="py-2">选项 1</li>
            <li className="py-2">选项 2</li>
            <li className="py-2">选项 3</li>
          </ul>
        </m.div>
      )} */}
    </div>
  );
}

export default HeaderImage;
